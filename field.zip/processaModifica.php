<?php
include_once "config.php";
include_once "connection.php";
session_start();

$conexao = new Connection($host, $user, $password, $database);

$id= $_POST['id'];
$endereco= $_POST['endereco'];
$numero= $_POST['numero'];
$gravidade= $_POST['gravidade'];
// $numDenuncias= $_POST['numDenuncias']
$conteudoImagem=$_FILES["imagem"]["tmp_name"];
$tamanhoImagem=$_FILES["imagem"]["size"];
$stats= $_POST['status'];
$lat= $_POST['lat'];
$lng= $_POST['lng'];
if(isset($_SESSION['idUsuario']))
{
  if($_SESSION['permissao']==='admin'){
 if($_SERVER['HTTP_REFERER'] === $url.'atualizar.php?id='.$id)
{   
                    $fp = fopen($conteudoImagem, "rb");
					$conteudoIm = fread($fp, $tamanhoImagem);
					$conteudoIm = addslashes($conteudoIm);
					fclose($fp);
  $sql= "UPDATE terreno SET endereco='$endereco',numero='$numero',gravidade='$gravidade',status='$stats',imagem='$conteudoIm',lat='$lat',lng='$lng' WHERE id='$id'";
  $conexao->query($sql);
  header("Refresh: 0; url=inicial2.php");?>
  <script>
  alert("Modificação realizada com sucesso!");
  </script>
<?php
}
}else{ 
header("Refresh: 0; url=inicial2.php");
?>
  <script>
  alert("Você não tem permissão para acessar essa página");
  </script>
  <?php
}
}else{
?>
<?php
header("Refresh: 0; url=index.html");?><script>alert("Precisa estar logado para efetuar a operação");</script>
<?php
}
//INNERJOIN para mudar status da denuncia
?>