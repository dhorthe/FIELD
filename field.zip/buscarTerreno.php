<?php
include_once "config.php";
include_once "connection.php";
session_start();
$conexao = new Connection($host, $user, $password, $database);
?>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width-device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
	<style media="screen">
	@media (max-width: 600px){
		.mtsm{
			margin-top: 5% !important;;
		}
	}
			.comum{
			font-family: 'Luckiest Guy', cursive;
			font-family: 'Lalezar', cursive;
		}
	</style>
  	<title>Busca de terrenos</title>
</head>
	<body>
		<nav class="navbar navbar-expand-lg bg-dark justify-content-center inline">
			 <a href="inicial2.php"><img src="imagem/logoField2.png" alt=""></a>
				<a class="navbar-right ml-auto mr-3" id="nomeUsuario"style="color:gray;"></a>
					<a class="navbar-right btn btn-dark comum" href="saida.php"> Sair </a>
			</div>
			</div>

		</nav>
			<div class="container m-center mt-5 form-control col-sm-12">



			<form action="buscarTerreno.php" method="POST">
				<br>
        <p class="comum"> Veja se o terreno que deseja denunciar já não existe:</p>
        <input class="form-control comum" type="text" placeholder="Nome da rua" name="rua" id="rua" required><br>
        				<input class="btn btn-dark comum" type="submit" name="Buscar" value="Buscar">
                	 <a class='btn btn-dark text-center mr-2 float-right comum' href='cadastroTerreno.php'>Cadastrar novo</a><br>
        <?php
    if(isset($_SERVER['HTTP_REFERER'])){
if($_SERVER['HTTP_REFERER'] === $url.'buscarTerreno.php')
{
  $rua=$_POST['rua'];

  $sql = "SELECT * FROM terreno WHERE endereco like '%$rua%'";

  $status = $conexao->query($sql);


  if($status === TRUE){
    $status = mysqli_query($conexao->getLink(), $sql);
    if($status->num_rows > 0){
    $imagem = mysqli_fetch_assoc($status);
    
    
    echo "<div class='row conteiner m-0 p-0'>";

    echo "<div class='my-auto mx-auto col-sm-12 col-lg-12 p-0'>";
    echo "<p style='font-size: 18px' class='text-center comum'>Aqui estão os terrenos já cadastrados</p>";
    echo "<p style='font-size: 18px' class='comum'>Aperte em selecionar se for qual deseja:</p>";
    	echo "<div class='table-responsive'>";
			echo "<div class='conteiner'>";
    echo "<table class='table table-dark comum' border=1 cellpadding=5 cellspacing=0>";
    echo "<tr>";
    echo "<th>Endereço</th>";
    echo "<th>Número</th>";
    echo "<th>Gravidade</th>";
    echo "<th>Imagem</th>";
    echo "<th>Escolher</th>";
    echo "</tr>";
    $numImage=0;
    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
    {
      $id=$tupla['id'];
      echo "<tr>";
      echo "<td>".$tupla['endereco']."</td> ";
      echo "<td>".$tupla['numero']."</td> ";
      echo "<td>".$tupla['gravidade']."</td> ";
      echo "<td>";
      echo '<img width="300px" height="200px" src="data:image/jpeg;base64,'.base64_encode($tupla['imagem']).'"/>';
      echo "</td>";
      echo "<td>"."<a class='btn btn-primary text-center comum' href='denuncia.php?id=$id' onclick='addnumDenuncia()'>Selecionar</a>"."</td> ";
				    
      echo "</tr>";
      $numImage++;
    }
    echo "</table>";
    echo "</div>";
    echo "<br>";
    echo "</div>";
   
    // echo $status;
    echo "</div>";
    echo "<a href='cadastroTerreno.php' class='comum'> Caso não tenha encontrado, cadastre um novo.</a>";
     echo "</div>";
  }
  else {
    echo "<p style='font-size: 20px; margin-top:200px;' class='text-center comum s'>Não foi encontrado nenhum registro com esse endereço</p>";
    echo "<br>";
    echo "<a class='btn btn-dark text-center comum btn-lg btn-block' href='cadastroTerreno.php'>Cadastre agora<a><br>";
  }
 }
}
// else{
// }
}

 ?>
 <!-- <a href="cadastroTerreno.php" class="comum"> Caso não tenha encontrado, cadastre um novo.</a> -->
				<!-- <input class="btn btn-dark comum" type="submit" name="Buscar" value="Buscar"> -->
				<!-- <a class='btn btn-dark text-center mr-2 float-right comum' href='cadastroTerreno.php'>Cadastrar novo<a><br> -->
			</form>
		</div>
	</body>
</html>
