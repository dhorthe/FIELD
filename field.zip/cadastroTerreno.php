<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
    <style media="screen">
      .comum{
        font-family: 'Luckiest Guy', cursive;
        font-family: 'Lalezar', cursive;
      }
    </style>

    <title>Cadastro</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-dark justify-content-center inline">
        <a href='inicial2.php'><img src="imagem/logoField2.png" alt=""></a>
      <a class="navbar-right ml-auto mr-3" id="nomeUsuario"style="color:gray;"></a>
      <a class="navbar-right btn btn-dark comum" href="saida.php">Sair</a>
    </nav>
    <div class='row conteiner mt-5 m-0 p-0'>
      <div class=' my-auto mx-auto px-2 col-xs-12 col-lg-6 p-0'>
      <form class="form-control" action="processa.php" method="post" enctype="multipart/form-data">

        <div class="form-group">
          <input class="form-control comum" type="text" placeholder="Endereço" name="endereco" value="" required>
        </div>
        <div class='row conteiner p-3'>
        <button class="btn btn-dark comum" type="button" onclick="getLocation()" required>Informar localização</button><p class='comum ml-3'>&larr; Clique no botão para podermos saber a localização exata do terreno</p>
        </div>
        <div id="msgcpf"></div>
        <br>
        <div class="form-group mt-3">
          <input class="form-control comum" type="number" placeholder="Número da propriedade" name="numero" value="" ><br>
        </div>

        <div class="form-group comum">
          <label for="gravidade">Gravidade</label>
          <ul>
            <input type="radio" name="gravidade" value="Baixo" required> Baixo<br>
            <input type="radio" name="gravidade" value="Moderado" required> Moderado<br>
            <input type="radio" name="gravidade" value="Crítico" required> Crítico<br>
            </ul>
            <br>
        </div>
          <div class="form-group comum">
            <label for="imagem">Insira a imagem do terreno</label>
            <input class="form-control-file" type="file" name="imagem" value=""><br>
          </div>
          <br>
          <input type="hidden" id="lat" name="latitude" value"">
          <input type="hidden" id="lng" name="longitude" value="">

          <input class="btn btn-dark fixed-right comum" type="submit" name="enviar" value="Enviar">
      </form>
    </div>
  </div>


      <script>
      
    document.getElementById("msgcpf").innerHTML="<font color='red' class='comum'>Localização não informada</font>";
      
var x=document.getElementById("d");
function getLocation()
  {
  if (navigator.geolocation)
    {
    navigator.geolocation.getCurrentPosition(showPosition,showError);
    }
  else{x.innerHTML="Seu browser não suporta Geolocalização.";}
  }
function showPosition(position)
  {
  document.getElementById('lat').value = position.coords.latitude;
  document.getElementById('lng').value =  position.coords.longitude;
  document.getElementById("msgcpf").innerHTML="<font color='green' class='comum'>Localização informada com sucesso </font>";
  x.innerHTML="Latitude: " + position.coords.latitude +
  "<br>Longitude: " + position.coords.longitude;
  }
function showError(error)
  {
  switch(error.code)
    {
    case error.PERMISSION_DENIED:
      x.innerHTML="Usuário rejeitou a solicitação de Geolocalização."
      break;
    case error.POSITION_UNAVAILABLE:
      x.innerHTML="Localização indisponível."
      break;
    case error.TIMEOUT:
      x.innerHTML="A requisição expirou."
      break;
    case error.UNKNOWN_ERROR:
      x.innerHTML="Algum erro desconhecido aconteceu."
      break;
    }
  }
</script>

  </body>
</html>
