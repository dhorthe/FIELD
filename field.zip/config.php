<?php
	$host = "localhost";
	$user = "id9867015_root";
	$password = "123456";
	$database = "id9867015_field";

	$url = "https://field2.000webhostapp.com/";

	$conn=mysqli_connect($host, $user, $password, $database);
?>
