<?php
	session_start();

	if(isset($_SESSION['idUsuario']))
	{
		session_destroy();
?>
<?php
header("Refresh: 0; url=index.html");?>
<?php
	}
?>
