<?php
session_start();
?>
<!DOCTYPE html>
<html class="h-100">
<head>
  <meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
  <link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
  <style media="screen">
    .comum{
      font-family: 'Luckiest Guy', cursive;
      font-family: 'Lalezar', cursive;
    }

@media (max-width: 600px){
  .pe{
    font-size: 15px !important;
  }
  .imgp{
    width: 100px !important;
    height: 100px !important;
  }
  .imgm{
    width: 300px !important;
    height: 150px !important;
  }
}
@media (max-width: 500px){
  .pp{
    font-size: 13.5px !important;
  }
  .imgsp{
    width: 50px;
    height: 50px;
  }
  .imgsm{
    width:300px;
    height:150px;
  }

}

  </style>
  <title>Dicas de Acompanhamento</title>
</head>
<body class="h-100">
  <nav class="navbar navbar-expand-lg bg-dark justify-content-center inline">

      <a href='inicial2.php'><img src="imagem/logoField2.png" alt=""></a>

    <a class="navbar-right ml-auto mr-3" id="nomeUsuario"style="color:gray;"></a>
    <a class="navbar-right btn btn-dark comum" href="saida.php">Sair</a>
  </nav>
  <div class="conteiner mt-5 p-0" style=" width:100%;">
      <div class="row ml-xs-0 mr-2 w-100">
        <div class='col-10 pr-0'>
        <input class='form-control  ml-1  w-lg-75 w-xs-75 comum' id="inputTest"/>
        </div>
        <div class="col-2 pl-1">
        <button class="comum btn btn-dark" onclick="copiarTexto()">Copiar</button>
      </div>
      </div>
      
      <script>
      let copiarTexto = () =>{
        //captura o elemento input
        const inputTest = document.querySelector("#inputTest");

        //seleciona todo o texto do elemento
        inputTest.select();
        //executa o comando copy
        //aqui é feito o ato de copiar para a area de trabalho com base na seleção
        document.execCommand('copy');
      };
      </script>
    <div class=" p-0">
      <p class="text-justify pl-2 comum ml-1 mr-1 pe">Este é o código de acompanhamento da sua denuncia. Guarde-o para conseguir visualizar o andamento da mesma.</p>
     
      <div class="col-lg-2 col-sm-1 m-0 p-0">
        <div class="card cardt border-0">
          <img class="card-img-top" src="imagem/acompanhaIcon.png" alt="Card image"></a>
          <div class="card-body m-0 p-0">
            <h5 class="card-text comum pe" style="text-align:center;">Acompanhar</h5>
          </div>
        </div>
      </div>
  
      <p class="text-justify comum ml-2 mr-1 pe"><b>1-</b> Para acompanhar o andamento basta clicar no ícone de acompanhar na página inicial.</p>
      <div class="col-lg-3 col-sm-2 m-0 p-0">
        <div class="card cardt border-0">
          <img class="card-img-top " src="imagem/dica2.png" alt="Card image"></a>
        </div>
      </div>
      <p class="text-justify comum ml-2"> <b>2-</b> Agora basta inserir no campo seu código que será encaminhado para página com detalhes da denuncia. </p>
      <?php
      
      if($_SESSION['permissao'] == "admin") {
        echo "<a class='btn btn-dark text-center mb-5 mr-4 float-right comum' href='inicial2.php'>Concluir</a>";
      }else{
        echo "<a class='btn btn-dark text-center mr-4 float-right comum' href='inicial2.php'>Concluir</a>";
      }
      ?>
    </div>
  </div>
  <script src="curso/node_modules/jquery/dist/jquery.js"></script>
  <script src="curso/node_modules/popper.js/dist/umd/popper.js"></script>
  <script src="curso/node_modules/bootstrap/dist/js/bootstrap.js"></script>
</body>
</html>
<script>

var url = window.location.href;
var cod = url.split('=')[1];
//alert(url); //teste se pega a url
//alert(cod); //teste mostra id terreno
document.getElementById('inputTest').value = cod;
</script>
