<html>
<head>
	<title>Busca de terrenos</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
	<style media="screen">
	@media (max-width: 600px){
		.mtsm{
			margin-top: 5% !important;;
		}
	}
			.comum{
			font-family: 'Luckiest Guy', cursive;
			font-family: 'Lalezar', cursive;
		}
	</style>
</head>
	<body>
		<nav class="navbar navbar-expand-lg bg-dark justify-content-center p-0">
			 <a href="inicial2.php"><img class="float-right" src="imagem/logoField2.png" alt=""></a>
				<a class="navbar-right my-auto ml-auto mr-2 pe pi" id="nomeUsuario"style="color:gray;"></a>
					<a class="navbar-right btn btn-dark mb-sm-2 mt-sm-2 mr-sm-2 px-3 float-right comum" href="saida.php"> Sair </a>
			</div>
			</div>

		</nav>
			<div class="container m-center mt-5 form-control col-sm-4">
			<form action="processaBusca.php" method="POST">
				<br>
        <input class="form-control comum" type="text" placeholder="Nome da rua" name="rua" id="rua" required>
<br>

				<input class="btn btn-dark comum" type="submit" name="Buscar">
				<a class='btn btn-dark text-center mr-2 float-right comum' href='inicial2.php'>Voltar a página inicial<a><br>
			</form>
		</div>
	</body>
</html>
