<!-- <?php
// session_start();
//
// if(isset($_SESSION['idUsuario'])){
// 	echo("Opa. Parece que tivemos um erro");
// 	header("Refresh: 0; url= inicial2.php");
// }
?> -->
<html>
<head>
	<title>Cadastro de Usuário</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
	<style media="screen">
	@media (max-width: 600px){
		.mtsm{
			margin-top: 5% !important;;
		}
	}
		.comum{
			font-family: 'Luckiest Guy', cursive;
			font-family: 'Lalezar', cursive;
		}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg bg-dark justify-content-center p-0">
					<a href="inicial2.php"><img class="float-right" src="imagem/logoField2.png" alt=""></a>
					<a class="navbar-right my-auto ml-auto mr-2 pe pi" id="nomeUsuario"style="color:gray;"></a>
    		<a class="navbar-right btn btn-dark mr-2 comum" href="saida.php"> Sair </a>
	</nav>

		<div class="container m-center mt-5 form-control col-sm-4" style="border-style:solid; border-color:">
			<form class="comum" name="cadastro" enctype="multipart/form-data" action="processa.php" method="POST" onSubmit="return verifica();">
				<div class="form-group comum">
					<br>
					<input class="form-control" type="text" placeholder="Nome" name="nome" id="nome">
				</div>

				<div class="form-group comum">
					<input class="form-control" type="text" placeholder="Exemplo@exemplo.com" name="email" onblur="validacaoEmail(cadastro.email)" id="email">
				</div><div id="msgemail"></div>

				<div class="form-group comum">
					<input class="form-control" type="text" placeholder="Login" name="login" id="login">
				</div>

				<div class="form-group comum">
					<input class="form-control" type="number" onclick="atencao()" onblur="validacaoCPF(cadastro.CPF)" placeholder="CPF" name="CPF" id="CPF">
				</div><div id="msgcpf"></div>

				<div class="form-group comum">
					<input class="form-control" type="password" placeholder="Senha" name="senha" id="senha">
					<br>
				</div>

				<div class="form-group comum">
					<input class="form-control" type="password"  placeholder="Confirme a senha" name="confirmarSenha" id="confirmarSenha">
					<br>
				</div>

				<div class="form-group comum">
					<select name="permissao">
						<option value="padrao">Usuario padrão</option>
						<<option value="admin">Administrador</option>

					</select>
					<br>
				</div>

				<input class="btn btn-dark comum" type="submit" name="Cadastrar" value="Cadastrar">
				<a class='btn btn-dark text-center mr-2 float-right comum' href='inicial2.php'>Voltar a página inicial<a><br>
				<script type="text/javascript">
				//verifica Email
				function validacaoEmail(field) {
					usuario = field.value.substring(0, field.value.indexOf("@"));
					dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);
					if ((usuario.length >=1) &&
					(dominio.length >=3) &&
					(usuario.search("@")==-1) &&
					(dominio.search("@")==-1) &&
					(usuario.search(" ")==-1) &&
					(dominio.search(" ")==-1) &&
					(dominio.search(".")!=-1) &&
					(dominio.indexOf(".") >=1)&&
					(dominio.lastIndexOf(".") < dominio.length - 1)) {
						document.getElementById("msgemail").innerHTML="<font color='green''>Email válido </font>";
					}
					else{
						document.getElementById("msgemail").innerHTML="<font color='red'>Email inválido </font>";
					}
				}
				//verifica CPF
				function validacaoCPF(field){
					if (field.value.length !== 11) {
						document.getElementById("msgcpf").innerHTML="<font color='red'>CPF inválido </font>";
					}else{
						document.getElementById("msgcpf").innerHTML="<font color='green'>CPF válido </font>";
					}
				}
				//verifica se estam preenchidos os campos
				function verifica(){
					var nome, email, login, CPF, senha, confirmarSenha;

					if(document.cadastro.nome.value==""){
						alert("Você deve preencher o Nome corretamente");
						document.cadastro.nome.focus();
						return false;
					}
					if (document.cadastro.email.value=="") {
						alert("Você deve preencher o email corretamente");
						document.cadastro.email.focus();
						return false;
					}
					if (document.cadastro.login.value=="") {
						alert("Você deve preencher o login corretamente");
						document.cadastro.login.focus();
						return false;
					}
					if (document.cadastro.CPF.value=="") {
						alert("Você deve preencher o CPF corretamente");
						document.cadastro.CPF.focus();
						return false;
					}
					if (document.cadastro.senha.value=="") {
						alert("Você deve preencher a senha corretamente");
						document.cadastro.senha.focus();
						return false;
					}
					if (document.cadastro.confirmarSenha.value=="") {
						alert("Você deve confirmar a senha corretamente");
						document.cadastro.confirmarSenha.focus();
						return false;
					}
					if (document.cadastro.senha.value.length < 6) {
						alert("Você deve informar uma senha maior com no mínimo 6 caractéres");
						document.cadastro.confirmarSenha.focus();
						return false;
					}
					if (document.cadastro.confirmarSenha.value != document.cadastro.senha.value) {
						alert("Senhas não correspondem");

						document.cadastro.confirmarSenha.focus();
						return false;
					}

				}
				var cont = 0;
				if (cont == 0) {
					function atencao(){
						if (cont == 0) {
							alert("Somente números");
						}
						cont = 1;
					}
				}

				</script>
			</form>
		</div>

	</div>
</body>
</html>
