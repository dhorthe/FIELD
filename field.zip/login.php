<?php
session_start();
	if(isset($_SESSION['idUsuario'])){
?>
<?php
header("Refresh:0; url= inicial2.php");?><script type="text/javascript">
		alert("A última sessão não foi encerrada...");
	</script>
<?php
}
include_once "config.php";
include_once "connection.php";
$conexao = new Connection($host, $user, $password, $database);




	date_default_timezone_set("America/Sao_Paulo");
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	require 'PHPMailer/PHPMailer/src/Exception.php';
	require 'PHPMailer/PHPMailer/src/PHPMailer.php';
	require 'PHPMailer/PHPMailer/src/SMTP.php';
	require 'PHPMailer/PHPMailer/src/OAuth.php';
	if (isset($_POST['acao']) && $_POST['acao'] == 'recuperar'):
		$email= strip_tags(filter_input(INPUT_POST, 'emailRecupera', FILTER_SANITIZE_STRING));

		$sql = "SELECT email FROM usuario WHERE email ='$email'";
		$conexao->query($sql);

		if($conexao->num_rows() ==1) {
			echo "$email";
			$codigo = base64_encode($email);
			$data_expirar= date('Y-m-d H:i:s', strtotime('+1 day'));

			try {
				$mail = new PHPMailer;
				$mail->IsSMTP();
				$mail->SMPTSecure = 'starttls';

				$mail->Host = 'smtp-mail.outlook.com';
				$mail->SMTPAuth = true;
				$mail->Port = 587;
				$mail->Username ='field-rescue@outlook.com';
				$mail->Password = 'Senh@124';
	$mail->CharSet = 'UTF-8';
				$mail->SetFrom('field-rescue@outlook.com','Field');
				$mail->AddReplyTo('field-rescue@outlook.com','Field');
				$mail->Subject='Alteração da senha';

				//EMAIL DO USUARIO
				$mail->AddAddress($email,'Alteração da senha');

				$mail ->MsgHTML('<p>Recebemos uma tentativa de recuperação de senha para este e-mail, caso não tenha sido você, desconsidere este e-mail, caso contrário clique no link abaixo <br /> <a href="localhost/NEW/recuperar.php?codigo='.$codigo.'">Link</a> </p>');


				$enviado = $mail->Send();

						//ISSO VERIFICA SE O EMAIL FOI ENVIADO TAOQUEI


						if ($enviado) {
					echo "sucesso";
					$sql2 = "INSERT INTO recuperacao_senha SET codigo_re = '$codigo', data = '$data_expirar'";
					$conexao->query($sql2);
?>
<?php
header("Refresh: 0; url=login.php");?><script type="text/javascript">
					alert( "Link enviado para o email com sucesso" );
					</script>
<?php
					exit(0);
				}else {
 ?>
 <?php
header("Refresh: 2; url=login.php");?><script type="text/javascript"> alert("erro, tente novamente");</script>
<?php
					exit(0);
				}



			}catch (phpmailerException $e) {
						echo $e->errorMessage();
					}
		}else {
?>
<?php
header("Refresh: 2; url=login.php");?><script type="text/javascript">alert("Email não cadastrado");
					</script>
<?php
					exit(0);
					}
	endif;
?>
	<!DOCTYPE html>
	<html class='h-100'>
	<head>
		<title>Acesso</title>
		<meta name="viewport" content="width-device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" type="text/css" href="estilos.css">
		<link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
		<link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
		<style media="screen">
      .comum{
        font-family: 'Luckiest Guy', cursive;
        font-family: 'Lalezar', cursive;
      }
    </style>
	</head>
	<body class='h-100'>
		<nav class="navbar navbar-expand-lg bg-dark justify-content-center mb-5 py-1 p-0">
					<a class="navbrand" href="index.html">
						<img href="index.html" class="navbar-brand" src="imagem/logoField2.png" alt="">
					</a>
		</nav>
		<?php
		if (isset($_GET['recuperar']) && $_GET['recuperar'] == 'sim') {
			?>

			<form class="comum" action="" method="post" enctype="multipart/form-data"  name="dados" onSubmit="return enviardados_user();">
				<p class="text-center comum">Informe o email de recuperação</p>
				<input class=" form-control comum" type="text" name="emailRecupera" placeholder="E-mail" style="text-align: center;background-color:white;border-style:none; width:100%;">

				<input type="hidden" name="acao" value="recuperar">

				<input class="btn btn-dark comum" type="submit" value="Recuperar Senha" style="color:white; font-size:23px;">

				<script type="text/javascript">
				function enviardados_user(){

					var motivo;

					//verifica campos vazios
					if(document.dados.emailRecupera.value=="")
					{
						document.dados.emailRecupera.focus();
						return false;
					}
				}
				</script>

			</form>



		<?php } else{?>

<div class="row conteiner mt-5 m-0 p-0">
<div class="my-auto mx-auto px-2 col-xs-12 col-lg-6 p-0">
<p class="text-center comum">Faça o login para continuar</p>


		<form class="form-control"action="processa.php" method="POST">
			<div class="form-group">

				<input class="form-control comum" placeholder='Login' type="text" name="login" required>
			</div>

			<div class="form-group">

				<input class="form-control comum"type="password"  placeholder="Senha" name="senha" required>
			</div>

			<input class="btn btn-dark w-100 comum"  type="submit" value='Acessar'> 	<a class="comum" href="?recuperar=sim" style="text-align:right;color:black;">Esqueceu sua senha?</a>

		</form>

	<a class="comum" href="cadastroUsuario.html"><p class="mt-1 text-center">Criar uma conta</p></a>
</div>
</div>

<?php } ?>
</body>
</html>
