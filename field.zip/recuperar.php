<?php
include_once "config.php";
include_once "connection.php";

$conexao = new Connection($host, $user, $password, $database);

if (isset($_GET['codigo'])) {
  $codigo = $_GET['codigo'];
  $email_codigo = base64_decode($codigo);

  $sql = "SELECT * FROM recuperacao_senha WHERE codigo_re = '$codigo' AND data>NOW()";
  $conexao->query($sql);

  if ($conexao->num_rows() >= 1) {
    ?>
    <!DOCTYPE html>
    <html lang="en" dir="ltr">
    <head class="h-100">
      <meta charset="utf-8">
      <link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
      <link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
      <style media="screen">
        .comum{
          font-family: 'Luckiest Guy', cursive;
          font-family: 'Lalezar', cursive;
        }
      </style>
      <title>Recuperação de senha</title>
    </head>
    <body class="h-100">
      <nav class="navbar navbar-expand-sm bg-dark justify-content-center mb-5">
        <img src="imagem/logoField2.png" alt="">

  		</nav>
        <p class="text-center comum">Informe uma nova senha para continuar com a recuperação</p>
      <div class="container m-center form-control col-sm-4" style="height:92% border-style:solid; border-color:">

      <form action="" method="post" enctype="multipart/form-data" name="dados" onSubmit="return enviardados_user();">
        <div class="form-group">
          <input class="form-control comum" type="password" placeholder="Nova senha" name="novasenha" value="">
        </div>
        <div class="form-group">
            <input class="form-control comum" type="password" placeholder="Confirme a senha" name="novasenha2" value=""><br>
        </div>

            <input type="hidden" name="acao" value="mudar">


        <input class="btn btn-dark w-100 comum" type="submit" name="" value="Mudar">
        <script>
        function enviardados_user(){

          var nome, senha;

          //verifica campos vazios
          if(document.dados.novasenha.value==""|| document.dados.novasenha.value.length <= 5)
          {
            alert( "Preencha campo SENHA corretamente!, ela deve conter no minimo 6 caracteres" );
            document.dados.novasenha.focus();
            return false;
          }

          if(document.dados.novasenha2.value==""|| document.dados.novasenha2.value.length <= 5)
          {
            alert( "Preencha campo SENHA corretamente!, ela deve conter no minimo 6 caracteres" );
            document.dados.novasenha2.focus();
            return false;
          }
        }
        </script>


      </form>
    </div>
    </body>
    </html>



    <?php
    if (isset($_POST['acao']) && $_POST['acao'] == 'mudar') {
      $nova_senha = $_POST['novasenha'];
      $nova_senha2 = $_POST['novasenha2'];
      $nova_senha = sha1($nova_senha);
      $nova_senha2 = sha1($nova_senha2);

      if ($nova_senha == $nova_senha2) {
        $sql = "UPDATE usuario SET senha = '$nova_senha' WHERE email = '$email_codigo'";
        $conexao->query($sql);

        if ($conexao->query($sql) == true) {
          $sql = "DELETE FROM recuperacao_senha WHERE codigo_re = '$codigo'";
          $conexao->query($sql);
          ?>
          <script type="text/javascript">
          alert( "Senha modificada" );
          </script>
          <?php

          header("Refresh: 0; url=login.php");
          exit(0);
        }
      }else {
        echo "senhas diferentes";
        header("Refresh: 0; url=recuperar.php");
        exit(0);
      }
    }
  }
}else {
  echo "Desculpe mas este link já expirou!!";
}
?>
