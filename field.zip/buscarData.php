<html>
<head>
	<title>Busca de terrenos</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
	<style media="screen">
	@media (max-width: 900px){
		.mtsm{
 			margin-top: 5% !important;;
 		}
	}

		.comum{
			font-family: 'Luckiest Guy', cursive;
			font-family: 'Lalezar', cursive;
		}
	</style>
</head>
	<body>
		<nav class="navbar navbar-expand-lg bg-dark justify-content-center p-0">

						<a href="inicial2.php"><img class="float-right" src="imagem/logoField2.png" alt=""></a>
				<a class="navbar-right my-auto ml-auto mr-2 pe pi" id="nomeUsuario"style="color:gray;"></a>
	    		<a class="navbar-right btn btn-dark mb-sm-2 mt-sm-2 mr-sm-2 px-3 float-right comum mtsm" href="saida.php"> Sair </a>

		</nav>
		<div class="container m-center mt-5 form-control col-sm-4">
			<form action="processaBusca.php" method="POST"><br>
				<p class="text-center comum" > Selecione o período que deseja buscar</p><br>
        <label class="comum" for="data1">De</label>
        <input class="form-control w-50 comum" type="date" name="data1" id="data1" required>

        <label class="comum" for="data2"> à </label>
        <input class="form-control w-50 comum" type="date" name="data2" id="data2" required>
        <br><br>
				<input class="btn btn-dark comum" type="submit" name="Buscar">
				<a class='btn btn-dark text-center mr-2 float-right comum' href='inicial2.php'>Voltar a página inicial<a><br>
			</form>
		</div>
	</body>
</html>
