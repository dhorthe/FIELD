<?php
session_start();
include_once "config.php";
include_once "connection.php";


$conexao = new Connection($host, $user, $password, $database);

//--------------------------------------------------------------------------- Login  ----------------------------------------------------

if($_SERVER['HTTP_REFERER'] === $url.'login.php')
{
	$login = $_POST['login'];
	$senha = $_POST['senha'];
	$senha = sha1($senha);

	if( (empty($login) == TRUE) || (empty($senha) == TRUE) )
	{
?>
<?php
header("Refresh: 0; url=login.php");?><script>alert("Você deve preencher todos os campos corretamente!");</script>
<?php
		exit(0);
	}
	else
	{
		$sql = "SELECT * FROM usuario WHERE login = '$login'";

		$conexao->query($sql);

		if($conexao->num_rows() > 0)
		{
			$sql = "SELECT permissao,idUsuario, nome AS n FROM usuario WHERE login = '$login' AND
			senha = '$senha'";

			$conexao->query($sql);

			if($conexao->num_rows() > 0)
			{
				$tupla = $conexao->fetch_assoc();
				$idUsuario = $tupla['idUsuario'];
				$nome = $tupla['n'];
				$perm=$tupla['permissao'];

				$_SESSION['idUsuario'] = $idUsuario;
				$_SESSION['nome'] = $nome;
				$_SESSION['permissao'] = $perm;

				header("Refresh: 0; url=inicial2.php");
				exit(0);
			}
			else
			{
?>
<?php
header("Refresh: 0; url=login.php");?><script>alert("Login e senha não correspondem");</script>
<?php
				exit(0);
			}

		} else{
?>
<?php
header("Refresh: 0; url=login.php");?><script>alert("Login inexistente, email não é login");</script>
<?php
		}
	}
}
else
{

	//--------------------------------------------------------------------------- Cadastro de Usuario admin----------------------------------------------------
	if($_SERVER['HTTP_REFERER'] === $url.'cadastroUsuario.php')
	{
		$login = $_POST['login'];
		$senha = $_POST['senha'];
		$confirmarSenha = $_POST['confirmarSenha'];
		$nome = $_POST['nome'];
		$CPF= $_POST['CPF'];
		$email = $_POST['email'];
		$permissao=$_POST['permissao'];

		if( (empty($login) == TRUE) || (empty($senha) == TRUE) || (empty($nome) == TRUE) || (empty($CPF) == TRUE) || (empty($email) == TRUE) || (empty($permissao) == TRUE))
		{
?>
<?php
header("Refresh: 0; url=cadastroUsuario.php");?><script>alert("Você deve preencher todos os campos corretamente!"); </script>
<?php
			exit(0);
		}

		if($senha !== $confirmarSenha)
		{
?>
<?php
header("Refresh: 0; url=cadastroUsuario.php");?><script>alert("Senhas não correspondem");</script>
<?php
			exit(0);

		}
		$sql = "SELECT * from usuario WHERE CPF = '$CPF'";

		$conexao->query($sql);

		if ($conexao->num_rows() > 0) {
?>
<?php
header("Refresh: 0; url=cadastroUsuario.php");?><script>alert("CPF já cadastrado, tente novamente ");</script>
<?php
		}else{

			$senha = sha1($senha);


			$sql = "INSERT INTO usuario(login, nome, CPF, email, senha, permissao) VALUES
			('$login', '$nome', '$CPF', '$email','$senha','$permissao')";

			$status = $conexao->query($sql);

			if($status === TRUE)
			{
?>
<?php
header("Refresh: 0; url=inicial2.php");?><script>alert("Cadastro feito com sucesso!");</script>
<?php
				exit(0);
			}
		}
	} else {


		//--------------------------------------------------------------------------- Cadastro de Usuario Comum-------------------------------------

		if($_SERVER['HTTP_REFERER'] === $url.'cadastroUsuario.html')
		{
			$login = $_POST['login'];
			$senha = $_POST['senha'];
			$confirmarSenha = $_POST['confirmarSenha'];
			$nome = $_POST['nome'];
			$CPF= $_POST['CPF'];
			$email = $_POST['email'];
			$permissao=$_POST['permissao'];

			if( (empty($login) == TRUE) || (empty($senha) == TRUE) || (empty($nome) == TRUE) || (empty($CPF) == TRUE) || (empty($email) == TRUE) || (empty($permissao) == TRUE))
			{
?>
<?php
header("Refresh: 0; url=cadastroUsuario.html");?><script>alert("Você deve preencher todos os campos corretamente!"); </script>
<?php
				exit(0);
			}

			if($senha !== $confirmarSenha)
			{
?>
<?php
header("Refresh: 0; url=cadastroUsuario.html");?><script>alert("Senhas não correspondem");</script>
<?php
				exit(0);

			}
			$sql = "SELECT * from usuario WHERE CPF = '$CPF'";

			$conexao->query($sql);

			if ($conexao->num_rows() > 0) {
?>
<?php
header("Refresh: 0; url=cadastroUsuario.html");?><script>alert("CPF já cadastrado, tente novamente");</script>
<?php
			}else{
			    	$sql = "SELECT * from usuario WHERE login = '$login'";

			$conexao->query($sql);

			if ($conexao->num_rows() > 0) {
?>
<?php
header("Refresh: 0; url=cadastroUsuario.php");?><script>alert("login já cadastrado, tente novamente ");</script>
<?php

}else{

				$senha = sha1($senha);


				$sql = "INSERT INTO usuario(login, nome, CPF, email, senha, permissao) VALUES
				('$login', '$nome', '$CPF', '$email','$senha','$permissao')";

				$status = $conexao->query($sql);

				if($status === TRUE)
				{
?>
<?php
header("Refresh: 0; url=index.html");?><script>("Cadastro feito com sucesso!");</script>
<?php
					exit(0);
				}
			}

			}
		}
		else {
			//--------------------------------------------------------------------------- Cadastro de Terreno-------------------------------------
			if($_SERVER['HTTP_REFERER'] === $url.'cadastroTerreno.php')
			{
				$endereco = $_POST['endereco'];
				$numero = $_POST['numero'];
				$gravidade = $_POST['gravidade'];
				$conteudoImagem=$_FILES["imagem"]["tmp_name"];
				$tamanhoImagem=$_FILES["imagem"]["size"];
				$latitude=$_POST['latitude'];
				$longitude=$_POST['longitude'];
				
				if ($numero === "") {
					$numero = "0";
				}
				//var_dump($numero);
				//exit(0);
				if( (empty($endereco) == TRUE) )
				{
?>
<?php
header("Refresh: 0; url=cadastroTerreno.php");?><script>alert("Você deve preencher todos os campos corretamente!");</script>
<?php
					exit(0);
				}
				if( (empty($latitude) == TRUE) || (empty($longitude) == TRUE) ){
					if ( $conteudoImagem != null )
					{
						$fp = fopen($conteudoImagem, "rb");
						$conteudoIm = fread($fp, $tamanhoImagem);
						$conteudoIm = addslashes($conteudoIm);
						fclose($fp);

						$sql = "INSERT INTO terreno(endereco, numero, gravidade, status, imagem, numDenuncias, lat, lng) VALUES
						('$endereco', '$numero', '$gravidade', 'none', '$conteudoIm','0' ,'0', '0')";

						$status = mysqli_query($conexao->getLink(), $sql);

						// exit(0);
						if($status === TRUE)
						{
							$last_id = mysqli_insert_id($conexao->getLink());

							header("Refresh: 0; url=denuncia.php?id=".$last_id);
							exit(0);
						} else{
?>
<?php
header("Refresh: 0; url=cadastroTerreno.php");?><script>alert("Houveram problemas ao conectar com o banco de dados, por favor tente novamente. 1111");</script>
<?php
					exit(0);
						}
					}else{
							$sql = "INSERT INTO terreno(endereco, numero, gravidade, status, imagem, numDenuncias, lat, lng) VALUES
 							('$endereco', '$numero', '$gravidade', 'none', 'none','0' ,'0', '0')";

							$status = mysqli_query($conexao->getLink(), $sql);

							// exit(0);
							if($status === TRUE)
							{
								$last_id = mysqli_insert_id($conexao->getLink());

								header("Refresh: 0; url=denuncia.php?id=".$last_id);
								exit(0);
							} else{
?>
<?php
header("Refresh: 0; url=cadastroTerreno.php");?><script>alert("Houveram problemas ao conectar com o banco de dados, por favor tente novamente. 2222");</script>
<?php
exit(0);
							}
						}
				}
				if ( $conteudoImagem != null )
				{
					$fp = fopen($conteudoImagem, "rb");
					$conteudoIm = fread($fp, $tamanhoImagem);
					$conteudoIm = addslashes($conteudoIm);
					fclose($fp);


						$sql = "INSERT INTO terreno(endereco, numero, gravidade, status, imagem, numDenuncias, lat, lng) VALUES
						('$endereco', '$numero', '$gravidade', 'none', '$conteudoIm','0' ,'$latitude', '$longitude')";

						$status = mysqli_query($conexao->getLink(), $sql);

						// exit(0);
						if($status === TRUE)
						{
							$last_id = mysqli_insert_id($conexao->getLink());

							header("Refresh: 0; url=denuncia.php?id=".$last_id);
							exit(0);
						} else{
?>
<?php
header("Refresh: 0; url=cadastroTerreno.php");?><script>alert("Houveram problemas ao conectar com o banco de dados, por favor tente novamente. 33333");</script>
<?php
						}
					}else{
					    $sql = "INSERT INTO terreno(endereco, numero, gravidade, status, imagem, numDenuncias, lat, lng) VALUES
						('$endereco', '$numero', '$gravidade', 'none', 'none','1' ,'$latitude', '$longitude')";

						$status = mysqli_query($conexao->getLink(), $sql);

					    if($status === TRUE)
						{
							$last_id = mysqli_insert_id($conexao->getLink());

							header("Refresh: 0; url=denuncia.php?id=".$last_id);
							exit(0);
						} else{
?>
<?php
header("Refresh: 0; url=cadastroTerreno.php");?><script>alert("Houveram problemas ao conectar com o banco de dados, por favor tente novamente. 44444");</script>
<?php
						}
					}



				}
			}
		}
	}
?>
