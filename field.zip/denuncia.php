<?php
session_start();
if(!isset($_SESSION['idUsuario'])){
?>
<?php
header("Refresh: 0; url=login.php");?><script>alert("Querido usuário, não tente burlar as regras aqui. Faça login.");</script>
<?php
    exit(0);
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
    <style media="screen">
      .comum{
        font-family: 'Luckiest Guy', cursive;
        font-family: 'Lalezar', cursive;
      }
    </style>
    <title>Denunciar</title>
  </head>
  <body>
      <nav class="navbar navbar-expand-lg bg-dark justify-content-center inline"style="height:8%;">
    			<a href='inicial2.php'><img class="navbrand" src="imagem/logoField2.png" alt=""></a>
    		<a class="navbar-right ml-auto mr-3" id="nomeUsuario"style="color:gray;"></a>
    		<a class="navbar-right btn btn-dark comum" href="saida.php">Sair</a>
    	</nav>

      <a href="cadastroTerreno.php"><p class="text-center mt-4 comum">Cadastre o terreno que deseja denunciar</p></a><br>
	<div class='row conteiner m-0 p-0'style='height:92.5%;width:100%;'>
    <div class=' my-auto mx-auto px-2 col-sm-4 col-lg-6 p-0'>
      <form class="" action="processaDenuncia.php" method="post"><br>
    <div class="form-group">
      <p class="comum"> Situação atual:  <select name="status">
       <option class="comum" value="aberto">Aberto</option>
       <?php session_start();
         if($_SESSION['permissao']==='admin'){
            echo "<option class='comum' value="."confirmado".">Confirmado</option>";
            echo "<option class='comum' value="."notificado".">Notificado</option>";
            echo "<option class='comum' value="."finalizado".">Finalizado</option>";
         }
       ?>
      </select>
      </p>
    </div>
    <div class="form-group comum">
    <textarea class="w-100" placeholder=">Descreva a situação encontrada" name="comentario" title="Máximo de 80 caracteres" rows="8" cols="80"></textarea>
    </div>

<?php
      $fuso=new DateTimeZone('America/Campo_Grande');
      $data=new DateTime();
      $data->setTimeZone($fuso);

      echo  $data->format('d-m-Y H:i:s').'</br>';


 $dataDenuncia=date('d/m/y');
 // echo $dataDenuncia.'</br>';
 // echo date('h:i:s').'</br>';
?>
<br>
      <input  type="hidden" id="fk" name="idT" value="">

          <input class="btn btn-dark comum" type="submit" name="enviar" value="Enviar">
      </form>
    </div>
    </div>

  </body>
</html>
<script>

  var url = window.location.href;
  var id = url.split('=')[1];
  // alert(url); teste se pega a url
  // alert(id); teste mostra id terreno
  document.getElementById('fk').value = id;
</script>
