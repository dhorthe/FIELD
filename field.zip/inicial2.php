<?php
session_start();
if(!isset($_SESSION['idUsuario']))
{
?>
<?php
header("Refresh:0; url='login.php'");?><script>
					alert("Você precisa estar logado para acessar o sistema.");
					</script>
<?php
}
?>
<!DOCTYPE html>
<html class="h-100">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width-device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
	<style media="screen">
@media (max-width: 900px){
	.pe{
		font-size: 18px !important;;
	}
}
@media (max-width: 600px){
	.pi{
		font-size: 12px !important;;
	}
	.pbx{
		padding-bottom: 5%;
	}
}
	.comum{
		font-family: 'Luckiest Guy', cursive;
		font-family: 'Lalezar', cursive;
	}
	.hb{
		height: 65%;
	}
@media (max-width: 550px){
    pp{
        font-size: 5px !important;;
    }
    
}
</style>
	<title>Página inicial</title>
</head>
<body class="h-100">
	<nav class="navbar navbar-expand-lg bg-dark justify-content-center inline">
						<img class="float-right" src="imagem/logoField2.png">
				<a class="navbar-right my-auto ml-auto mr-2 pe pi" id="nomeUsuario"style="color:gray;"></a>
				<a class="navbar-right btn btn-dark mb-sm-2 mt-sm-2 comum hb" href="saida.php">Sair</a>
			</div>
	</nav>
	<div class="row conteiner m-0 p-0"style='height:100%;'>
		<?php
	
			if($_SESSION['permissao']==='admin'){
				$nome=$_SESSION['nome'];
				$permissao=$_SESSION['permissao'];
				echo "<input type = 'hidden'"."id='nome'"."name='nome'"."value='".$nome."'>";
				// echo "<a href='cadastro.php'>Cadastrar</a><br>"
				echo "<div class='col-sm-2 col-2 p-0'>";
				echo "<div class='card' style='width:100%; border-style:none;'>";
				echo "<a href='buscarTerreno.php'><img class='card-img-top' src='imagem/denunciaIcon.png' alt='Card image'></a>";
				echo "<div class='card-body m-0 p-0'>";
				echo "<h4 class='card-text pe comum' style='text-align:center;'>Denunciar</h4>";
				echo "</div>";
				echo "</div>";
				echo "<div class='card' style='width:100%; border-style:none;'>";
				echo "<a href='cadastroUsuario.php'><img class='card-img-top' src='imagem/usuarioIcon.png' alt='Card image'></a>";
				echo "<div class='card-body m-0 p-0'>";
				echo "<h4 class='card-text pe comum' style='text-align:center;'>Cadastrar usuário</h4>";
				echo "</div>";
				echo "</div>";
				echo "<div class='card' style='width:100%; border-style:none;'>";
				echo "<a href='buscarData.php'><img class='card-img-top' src='imagem/pesquisaIcon.png' alt='Card image'></a>";
				echo "<div class='card-body m-0 p-0'>";
				echo "<h4 class='card-text pe comum' style='text-align:center;'>Pesquisar por data</h4>";
				echo "</div>";
				echo "</div>";
				echo "</div>";
				echo "<div class='col-sm-2 col-2 p-0'>";
				echo "<div class='card' style='width:100%; border-style:none;'>";
				echo "<a href='acompanhar.php'><img class='card-img-top' src='imagem/acompanhaIcon.png' alt='Card image'></a>";
				echo "<div class='card-body m-0 p-0'>";
				echo "<h4 class='card-text pe comum' style='text-align:center;'>Acompanhar</h4>";
				echo "</div>";
				echo "</div>";
				echo "<div class='card' style='width:100%; border-style:none;'>";
				echo "<a href='cadastroTerreno.php'><img class='card-img-top' src='imagem/terrenoIcon.png' alt='Card image'></a>";
				echo "<div class='card-body m-0 p-0'>";
				echo "<h4 class='card-text pe comum' style='text-align:center;'>Cadastrar terreno</h4>";
				echo "</div>";
				echo "</div>";
				echo "<div class='card' style='width:100%; border-style:none;'>";
				echo "<a href='buscarEndereco.php'><img class='card-img-top' src='imagem/ruaIcon.png' alt='Card image'></a>";
				echo "<div class='card-body m-0 p-0'>";
				echo "<h4 class='card-text pe comum' style='text-align:center;'>Pesquisar por rua</h4>";
				echo "</div>";
				echo "</div>";
				echo "</div>";
				echo "<div class='col-sm-8 col-8 m-0 p-0''>";
				echo "<div class='h-100' id='map'></div>";
				echo "</div>";
				?>
				<script>
				var customLabel = {
					restaurant: {
						label: 'R'
					},
					bar: {
						label: 'B'
					}
				};

				function initMap() {
					var map = new google.maps.Map(document.getElementById('map'), {
						center: new google.maps.LatLng(-20.461590, -54.616503),
						zoom: 12
					});
					var infoWindow = new google.maps.InfoWindow;

					// Change this depending on the name of your PHP or XML file
					downloadUrl('resultado.php', function(data) {
						var xml = data.responseXML;
						var markers = xml.documentElement.getElementsByTagName('marker');
						Array.prototype.forEach.call(markers, function(markerElem) {
							var numero = markerElem.getAttribute('numero');
							var endereco = markerElem.getAttribute('endereco');
							var type = markerElem.getAttribute('type');
							var point = new google.maps.LatLng(
								parseFloat(markerElem.getAttribute('lat')),
								parseFloat(markerElem.getAttribute('lng')));

								var infowincontent = document.createElement('div');
								var strong = document.createElement('strong');
								strong.textContent = numero
								infowincontent.appendChild(strong);
								infowincontent.appendChild(document.createElement('br'));

								var text = document.createElement('text');
								text.textContent = endereco
								infowincontent.appendChild(text);
								var icon = customLabel[type] || {};
								var marker = new google.maps.Marker({
									map: map,
									position: point,
									label: icon.label
								});
								marker.addListener('click', function() {
									infoWindow.setContent(infowincontent);
									infoWindow.open(map, marker);
								});
							});
						});
					}
					function downloadUrl(url, callback) {
						var request = window.ActiveXObject ?
						new ActiveXObject('Microsoft.XMLHTTP') :
						new XMLHttpRequest;

						request.onreadystatechange = function() {
							if (request.readyState == 4) {
								request.onreadystatechange = doNothing;
								callback(request, request.status);
							}
						};

						request.open('GET', url, true);
						request.send(null);
					}

					function doNothing() {}
					</script>
					<script async defer
					src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDjfzBnabMmuTAms2YeQYHlPGTyIYBLKns&callback=initMap">
					</script>
					<?php
					echo "</div>";
					echo "</div>";
				}else{
					$nome = $_SESSION['nome'];
					echo "<input type = 'hidden'"."id='nome'"."name='nome'"."value='".$nome."'>";
					// echo "<a href='cadastro.php'>Cadastrar</a><br>";
					echo "<div class='col-sm-2 col-2 m-0 p-0'>";
					echo "<div class='card' style='width:100%; border-style:none;'>";
					echo "<a href='buscarTerreno.php'><img class='card-img-top' src='imagem/denunciaIcon.png' alt='Card image'></a>";
					echo "<div class='card-body m-0 p-0'>";
					echo "<h4 class='card-text comum pi pe' style='text-align:center;'>Denunciar</h4>";
					echo "</div>";
					echo "</div>";
					
					
					echo "<div class='card' style='width:100%; border-style:none;'>";
					echo "<a href='acompanhar.php'><img class='card-img-top' src='imagem/acompanhaIcon.png' alt='Card image'></a>";
					echo "<div class='card-body m-0 p-0'>";
					echo "<h4 class='card-text comum pp pi pe' style='text-align:center;'>Acompanhar</h4>";
					echo "</div>";
					echo "</div>";
					echo "</div>";
					echo "<div class='col-sm-10 col-10 m-0 p-0'>";
					echo "<div class='h-100' id='map'></div>";
					echo "</div>";
					?>
					<script>
					var customLabel = {
						restaurant: {
							label: 'R'
						},
						bar: {
							label: 'B'
						}
					};

					function initMap() {
						var map = new google.maps.Map(document.getElementById('map'), {
							center: new google.maps.LatLng(-20.461590, -54.616503),
							zoom: 12
						});
						var infoWindow = new google.maps.InfoWindow;

						// Change this depending on the name of your PHP or XML file
						downloadUrl('resultado.php', function(data) {
							var xml = data.responseXML;
							var markers = xml.documentElement.getElementsByTagName('marker');
							Array.prototype.forEach.call(markers, function(markerElem) {
								var numero = markerElem.getAttribute('numero');
								var endereco = markerElem.getAttribute('endereco');
								var type = markerElem.getAttribute('type');
								var point = new google.maps.LatLng(
									parseFloat(markerElem.getAttribute('lat')),
									parseFloat(markerElem.getAttribute('lng')));

									var infowincontent = document.createElement('div');
									var strong = document.createElement('strong');
									strong.textContent = numero
									infowincontent.appendChild(strong);
									infowincontent.appendChild(document.createElement('br'));

									var text = document.createElement('text');
									text.textContent = endereco
									infowincontent.appendChild(text);
									var icon = customLabel[type] || {};
									var marker = new google.maps.Marker({
										map: map,
										position: point,
										label: icon.label
									});
									marker.addListener('click', function() {
										infoWindow.setContent(infowincontent);
										infoWindow.open(map, marker);
									});
								});
							});
						}
						function downloadUrl(url, callback) {
							var request = window.ActiveXObject ?
							new ActiveXObject('Microsoft.XMLHTTP') :
							new XMLHttpRequest;
							request.onreadystatechange = function() {
								if (request.readyState == 4) {
									request.onreadystatechange = doNothing;
									callback(request, request.status);
								}
							};
							request.open('GET', url, true);
							request.send(null);
						}
						function doNothing() {}
						</script>
						<script async defer
						src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDjfzBnabMmuTAms2YeQYHlPGTyIYBLKns&callback=initMap">
						</script>
						<?php
						echo "</div>";
						echo "</div>";
					}
				?>
			</div>
			<script src="curso/node_modules/jquery/dist/jquery.js"></script>
			<script src="curso/node_modules/popper.js/dist/umd/popper.js"></script>
			<script src="curso/node_modules/bootstrap/dist/js/bootstrap.js"></script>
		</body>
		</html>
		<script>
		var b = "Olá ";
		var a = document.getElementById('nome').value;
		var nomeUsuario = document.getElementById('nomeUsuario');
		nomeUsuario.innerHTML = b+a;
	</script>
