<?php
 session_start();
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
    <title>Acompanhar</title>
    <style media="screen">
      .comum{
        font-family: 'Luckiest Guy', cursive;
        font-family: 'Lalezar', cursive;
      }
    </style>
  </head>
  <body>

      <nav class="navbar navbar-expand-lg bg-dark justify-content-center inline"style="height:8%;">
    		<a <?php if (isset($_SESSION['idUsuario'])) {
          echo "href='inicial2.php'";
        }else {
          echo "href='index.html'";
        }?>>	<img src="imagem/logoField2.png" alt=""></a>
    		<a class="navbar-right ml-auto mr-4" id="nomeUsuario"style="color:gray;"></a>
    		<a class="navbar-right btn btn-dark mb-sm-2 mt-sm-2 comum"<?php
        if (isset($_SESSION['idUsuario'])) {
         //   $cod=md5($_SESSION['idUsuario']);
         // echo"<p>$cod</p>";
          echo "href='saida.php'>";
          echo "Sair </a>";
        }else {
          echo "href='login.php'>";
          echo "Entrar </a>";
        }
         ?></a>

    	</nav>
<p class="text-center mt-5 comum"style="">Insira o código disponibilizado ao termino da sua denuncia para continuar</p>
    <div class="container m-center form-control col-sm-4" style="border-style:solid; border-color:">

    <form class="p-2" action="processaBusca.php" method="POST">
      <div class="form-group">

        <?php
        if (isset($_SESSION['idUsuario'])) {
             $cod=md5($_SESSION['idUsuario']);
         // echo"<p>$cod</p>";
        echo "<input class='form-control comum' type='text' placeholder='Insira o código de acompanhamento' 
        name='codigo' id='codigo' value='$cod'>";
        }else
                echo "<input class='form-control comum' type='text' placeholder='Insira o código de acompanhamento' 
        name='codigo' id='codigo'>";
        ?>
      </div>

      <br>

      <input class="btn btn-dark w-100 comum" type="submit" name="Enviar" value="Enviar">
    </form>
    </div>
  </body>
</html>
