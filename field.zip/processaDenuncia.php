<?php
include_once "config.php";
include_once "connection.php";

session_start();

$conexao = new Connection($host, $user, $password, $database);

//resolvido se pah
  $data = date('Y-m-d H:i:s');
  $statu = $_POST['status'];
  $comentario = $_POST['comentario'];
  $fkUsuario = $_SESSION['idUsuario'];
  $fkTerreno = $_POST['idT'];
  $codAcompanhamento = md5($_SESSION['idUsuario']);

  if( (empty($statu) == TRUE) || (empty($comentario) == TRUE))
  {
?>
<?php
header("Refresh: 0; url=denuncia.php?id=".$fkTerreno);?><script>alert("Você deve preencher todos os campos corretamente!");
    </script>
<?php
    exit(0);
  }
  $sql = "INSERT INTO denuncia(comentario, dataPublicacao, codAcompanhamento, id_usuario,id_terreno) VALUES
  ('$comentario', NOW(), '$codAcompanhamento', '$fkUsuario','$fkTerreno')";

  $status = $conexao->query($sql);

  if($status === TRUE)
  {
    //teste
					    $sql = "UPDATE terreno SET numDenuncias = (numDenuncias+1), status = '$statu' WHERE id = $fkTerreno";
                        
						$status = mysqli_query($conexao->getLink(), $sql);

						if ($status === TRUE) {
						   
    						header("Refresh: 0; dicasAcompanhamento.php?cod=".$codAcompanhamento);
    						exit(0);
						}//fimteste  
    
/*?>
<?php
header("Refresh: 0; url=dicasAcompanhamento.php?cod=".$codAcompanhamento);?><script>alert("Denuncia efetuada com sucesso!");
    </script>
<?php
    exit(0);*/
  }

?>
