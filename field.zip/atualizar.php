<?php
include_once "config.php";
include_once "connection.php";
session_start();
$conexao = new Connection($host, $user, $password, $database);
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
    <link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
    <style media="screen">
      .comum{
        font-family: 'Luckiest Guy', cursive;
        font-family: 'Lalezar', cursive;
      }
    </style>

    <title>Modificando</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-dark justify-content-center inline">
        <img src="imagem/logoField2.png" alt="">
      <a class="navbar-right ml-auto mr-3" id="nomeUsuario"style="color:gray;"></a>
      <a class="navbar-right btn btn-dark comum" href="saida.php">Sair</a>
    </nav>
    <div class='container mt-5 m-center col-sm-4'>
<?php
if(isset($_SESSION['idUsuario']))
{
  if($_SESSION['permissao']==='admin'){
$id = isset($_GET ['id']) ? intval($_GET['id']) : 0;

if($id != 0) {
  $sql="SELECT * FROM terreno WHERE id=$id";
  //$sql = "SELECT * FROM terreno t JOIN denuncia d ON t.id=d.id_terreno WHERE t.id='$id'";
  $status = $conexao->query($sql);

//UPDATE denuncia SET status='finalizado' WHERE id_terreno=10

  if($status === TRUE){
    $status = mysqli_query($conexao->getLink(), $sql);
    if($status->num_rows > 0){
    $imagem = mysqli_fetch_assoc($status);
  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
  {
  ?>
      <p class="text-center comum" style="font-size:20px">Alteração dos dados do terreno</p>
      <form class="form-control" action="processaModifica.php" method="post" enctype="multipart/form-data">

        <div class="form-group">
          <input class="form-control comum" type="text" placeholder="Endereço" name="endereco" value="<?php echo $tupla['endereco']?>">
        </div>
        <!-- <button class="btn btn-dark comum" type="button" onclick="getLocation()">Informar localização</button> -->

        <div class="form-group mt-3">
          <input class="form-control comum" type="number" placeholder="Número da propriedade (opcional)" name="numero" value="<?php echo $tupla['numero']?>">
        </div>

        <div class="form-group comum">

          <label for="gravidade">Gravidade</label>
          <select name="gravidade">
            <option class="comum" value="<?php echo $tupla['gravidade']?>">atual:<?php echo $tupla['gravidade']?></option>
            <option value="Baixo"> Baixo<br>
            <option value="Moderado"> Moderado<br>
            <option value="Crítico"> Crítico<br>
          </select>

            <p class="comum"> Situação atual:  <select name="status">
              <option class="comum" value="<?php echo $tupla['status']?>">atual:<?php echo $tupla['status']?></option>
                <option class="comum" value="aberto">Aberto</option>
                <option class='comum' value="confirmado">Confirmado</option>;
                <option class='comum' value="notificado">Notificado</option>;
                <option class='comum' value="finalizado">Finalizado</option>;
            </select>

            <!-- <select name="permissao">
              <option value="Baixo">Baixo</option>
              <option value="Moderado">Moderado</option>
              <option value="Crítico">Crítico</option>
            </select> -->
            <input class="form-control comum" type="hidden" name="id" value="<?php echo $tupla['id']?>">
        </div>
          <div class="form-group comum">
<?php
            	echo '<img width="420px" height="300px" src="data:image/jpeg;base64,'.base64_encode($imagem['imagem']).'"/>';
              ?>
              <br>
              <label for="imagem">Insira imagem do terreno para substituir a atual:</label>
            <input class="form-control-file" type="file" name="imagem" value="">
          </div>
          <input class="form-control comum" id="lat" name="lat" value="<?php echo $tupla['lat']?>"><br>
          <input class="form-control comum"  id="lng" name="lng" value="<?php echo $tupla['lng']?>"><br>

          <input class="btn btn-dark m-auto comum" type="submit" name="enviar" value="Enviar">
          <a class='btn btn-dark text-center mr-2 float-right comum' href='inicial2.php'>Voltar a página inicial<a><br>
      </form>
    </div>
  </div>
<?php
}
}
}    // header("Refresh: 0; url=inicial2.php");
} else { ?>
  <script>
  alert("O id não existe ou é inválido");
  </script>
  <?php
    header("Refresh: 0; url=inicial2.php");
}
}else{?>
  <script>
  alert("Você não tem permissão para acessar essa página");
  </script>
  <?php
  header("Refresh: 0; url=inicial2.php");
}
}else{?>
  <script>
  alert("Precisa estar logado para efetuar a operação");
  </script>
  <?php
  header("Refresh: 0; url=index.html");
}
?>
