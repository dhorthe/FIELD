<?php
include_once "config.php";
include_once "connection.php";
session_start();
$conexao = new Connection($host, $user, $password, $database);

if(isset($_SESSION['idUsuario']))
{
  if($_SESSION['permissao']==='admin'){
$id = isset($_GET ['id']) ? intval($_GET['id']) : 0;

if($id != 0) {
  $sql = "DELETE FROM terreno WHERE id like '$id'";
  $status = $conexao->query($sql);
?>
<?php
header("Refresh: 0; url=inicial2.php");?><script>alert("Exclusão realizada com sucesso!");</script>
<?php
} else {
?>
<?php
header("Refresh: 0; url=inicial2.php");?> <script>alert("O id não existe ou é inválido");</script>
<?php
}
}else{
?>
<?php
header("Refresh: 0; url=inicial2.php");?><script>
  alert("Você não tem permissão para acessar essa página");
  </script>
<?php
}
}else{
?>
<?php
header("Refresh: 0; url=index.html");?><script>
  alert("Precisa estar logado para efetuar a operação");
  </script>
<?php
}
?>
