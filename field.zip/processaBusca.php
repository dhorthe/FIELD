<?php
include_once "config.php";
include_once "connection.php";

session_start();
 ?>
<!DOCTYPE html>
<html class="h-100">
<head class="h-100">
	<meta charset="utf-8">
	<link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Luckiest+Guy&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lalezar|Luckiest+Guy&display=swap" rel="stylesheet">
	<style media="screen">
		.comum{

			font-family: 'Luckiest Guy', cursive;
			font-family: 'Lalezar', cursive;
		}
	</style>
	<title>Página inicial</title>
</head>
<body class="h-100">

	  <nav class="navbar navbar-expand-lg bg-dark justify-content-center inline">
			<div class="">

			</div>
			<div class="ml-auto mr-5 pr-4">
				<img src="imagem/logoField2.png" alt="">
			</div>

			<a class="navbar-right ml-auto mr-3" id="nomeUsuario"style="color:gray;"></a>

			<a class="navbar-right btn btn-dark mb-sm-2 mt-sm-2 comum"<?php
			// session_start();
			if (isset($_SESSION['idUsuario'])) {
				echo "href='saida.php'>";
				echo "Sair";
			}else {
				echo "href='login.php'>";
				echo "Entrar";
			}
			//  session_destroy();?></a>

		</nav>

</body>
</html>
<?php


$conexao = new Connection($host, $user, $password, $database);

if($_SERVER['HTTP_REFERER'] === $url.'buscarData.php')
{
	$data1=$_POST['data1'];
	$data2=$_POST['data2'];
  

	$sql = "SELECT * FROM denuncia WHERE dataPublicacao between '$data1' AND '$data2'";

	$conexao->query($sql);
    
	for($tupla1 = $conexao->fetch_assoc(); $tupla1 != NULL; $tupla1 = $conexao->fetch_assoc())
	{
		$fk_terreno=$tupla1['id_terreno'];
		
  if(!empty($fk_terreno)){

	$sql = "SELECT  t.id,t.endereco,t.numero,t.gravidade,t.status,t.imagem FROM terreno t JOIN denuncia d ON d.id_terreno=$fk_terreno WHERE d.dataPublicacao between '$data1' AND '$data2'";
  // echo $sql;

	$status = $conexao->query($sql);
    
	if($status === TRUE){
		$statu = mysqli_query($conexao->getLink(), $sql);
		$imagem = mysqli_fetch_assoc($statu);
		echo "	<div class='container m-center mt-5 form-control col-sm-12'>";

			
			echo "<p style='font-size: 20px' class='text-center comum s'>Aqui estão todas as denuncias desse período</p>";
			echo "<div class='table-responsive'>";
			echo "<div class='conteiner'>";
			echo "<table class='table table-dark' border=1 cellpadding=5 cellspacing=0>";
			echo "<tr>";
			echo "<th>Endereço</th>";
			echo "<th>Número</th>";
			echo "<th>Gravidade</th>";
			echo "<th>imagem</th>";
      echo "<th>Exclusão</th>";
      echo "<th>Editar</th>";
			echo "</tr>";
	  
      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
      {
      $id=$tupla['id'];
      //$id= $fk_terreno['1'];
			echo "<tr>";
			echo "<td>".$tupla['endereco']."</td> ";
			echo "<td>".$tupla['numero']."</td> ";
			echo "<td>".$tupla['gravidade']."</td> ";
			// $fk_terreno=$tupla['id'];
			// echo $fk_terreno;
			echo "<td>";
			echo '<img width="200px" height="200px" src="data:image/jpeg;base64,'.base64_encode($tupla['imagem']).'"/>';
			echo "</td>";
      echo "<td>"."<a class='btn btn-danger text-center comum' href='excluir.php?id=$id'>Remover</a>"."</td> ";
      echo "<td>"."<a class='btn btn-primary text-center comum' href='atualizar.php?id=$id'>Atualizar</a>"."</td> ";
			echo "</tr>";
		
		}
  }

		echo "</table>";
		
		echo "<br>";
		echo "<a class='btn btn-dark text-center mr-2 float-right comum' href='inicial2.php'>Voltar a página inicial<a><br>";

		echo "</div>";

		echo "</div>";
		echo "<br>";
		echo "</div>";
	}else{
    echo "<p style='font-size: 20px; margin-top:200px;' class='text-center comum s'>Não foi encontrado nenhum cadastro nesse período</p>";
    echo "<br>";
    echo "<a class='btn btn-dark text-center comum btn-lg btn-block' href='inicial2.php'>Voltar a página inicial<a><br>";
}
}
}
//-------------------------------------------------
else{
	if($_SERVER['HTTP_REFERER'] === $url.'buscarEndereco.php')
	{
		$rua=$_POST['rua'];

		$sql = "SELECT * FROM terreno WHERE endereco like '%$rua%'";

		$status = $conexao->query($sql);


		if($status === TRUE){
			$status = mysqli_query($conexao->getLink(), $sql);
      if($status->num_rows > 0){
			$imagem = mysqli_fetch_assoc($status);
			echo "	<div class='container m-center mt-5 form-control col-sm-12'>";

			echo "<p style='font-size: 20px' class='text-center comum'>Aqui estão todas as suas denuncias relacionadas</p>";
			echo "<table class='table table-dark comum' border=1 cellpadding=5 cellspacing=0>";
			echo "<tr>";
			echo "<th>Endereço</th>";
			echo "<th>Número</th>";
			echo "<th>Gravidade</th>";
			echo "<th>Situação</th>";
			echo "<th>Imagem</th>";
      echo "<th>Exclusão</th>";
      echo "<th>Editar</th>";
			echo "</tr>";

			for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
			{
        $id=$tupla['id'];
				echo "<tr>";
				echo "<td>".$tupla['endereco']."</td> ";
				echo "<td>".$tupla['numero']."</td> ";
				echo "<td>".$tupla['gravidade']."</td> ";
				echo "<td>".$tupla['status']."</td> ";
				echo "<td>";
				echo '<img width="200px" height="200px" src="data:image/jpeg;base64,'.base64_encode($tupla['imagem']).'"/>';
				echo "</td>";
        echo "<td>"."<a class='btn btn-danger text-center comum' href='excluir.php?id=$id'>Remover</a>"."</td> ";
        echo "<td>"."<a class='btn btn-primary text-center comum' href='atualizar.php?id=$id'>Atualizar</a>"."</td> ";
				echo "</tr>";
			}
			echo "</table>";

			echo "<br>";
			echo "<a class='btn btn-dark text-center mr-2 float-right comum' href='inicial2.php'>Voltar a página inicial<a><br>";
			
      // echo $status;
			echo "</div>";
    }
    else {
      echo "<p style='font-size: 20px; margin-top:200px;' class='text-center comum s'>Não foi encontrado nenhum registro com esse endereço</p>";
      echo "<br>";
      echo "<a class='btn btn-dark text-center comum btn-lg btn-block' href='inicial2.php'>Voltar a página inicial<a><br>";
    }
   }
	}
	//------------------------------------------------------------------- Acompanhar----------------------------------------------------
	else{
		if($_SERVER['HTTP_REFERER'] === $url.'acompanhar.php')
		{
			$codAcompanhamento=$_POST['codigo'];

			// $sql = "SELECT * FROM denuncia WHERE codAcompanhamento = '$codAcompanhamento';";
      $sql = "SELECT * FROM denuncia d JOIN terreno t ON t.id=d.id_terreno WHERE d.codAcompanhamento='$codAcompanhamento'";

			$conexao->query($sql);

			if($conexao->num_rows() > 0){
				echo "<div class='row conteiner p-0'style='height:92.5%;'>";
				echo "<div class='col-sm-3 p-0'>";
				echo "</div>";
				echo "<div class=' my-auto col-sm-6 p-0'>";
				echo "<p style='font-size: 20px' class='text-center comum'>Aqui estão todas as suas denuncias registradas</p>";
				echo "<div class='table-responsive'>";
				echo "<table class='table table-dark' border=1 cellpadding=5 cellspacing=0>";
				echo "<tr>";
        echo "<th class='text-center'>Endereço</th>";
        echo "<th class='text-center'>Número</th>";
				echo "<th class='text-center'>Comentário</th>";
				echo "<th class='text-center'>Status</th>";
				echo "<th class='text-center pr-0'>Data / hora da denúncia</th>";
				//echo "<th>imagem</th>";
				echo "</tr>";

				for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
				{
					echo "<tr>";
                    echo "<td class='text-center'>".$tupla['endereco']."</td> ";
                    echo "<td class='text-center'>".$tupla['numero']."</td> ";
					echo "<td class='text-center'>".$tupla['comentario']."</td> ";
					echo "<td class='text-center'>".$tupla['status']."</td> ";
					echo "<td class='text-center pr-0'>".$tupla['dataPublicacao']."</td> ";
					//echo "<td>".$tupla['imagem']."</td> ";
					echo "</tr>";
				}
				echo "</table>";
				echo "</div>";
				echo "<br>";
				echo "<a class='btn btn-dark text-center mr-2 float-right comum' href='";
				if(isset($_SESSION['idUsuario'])){
				  echo "inicial2.php'>Voltar a página inicial<a><br>";  
				}else{
				   echo "index.html'>Voltar a página inicial<a><br>";  
				}
				

				echo "</div>";
				echo "<div class='col-sm-3 p-0'>";
				echo "</div>";
				echo "</div>";
			}else {
			echo "<div class='conteiner'>";
            echo "<p class='text-center comum'>Não encontramos o código de acompanhamento informado</p>";
            echo "<div class='col-2 mx-auto'>";
            echo "<a class='btn btn-dark comum' href='acompanhar.php'>Voltar para a página de acompanhamento";
            echo "</div>";
            echo "</div>";
		}
	}

}

}
?>
