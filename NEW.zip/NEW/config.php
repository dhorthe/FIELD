<?php
	$host = "localhost";
	$user = "root";
	$password = "";
	$database = "field";

	$url = "http://localhost/NEW/";
?>
