<?php
	session_start();

	if(isset($_SESSION['idUsuario'])){
		alert("pau en tu culo hermanito");
		header("url= inicial2.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Acesso</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
</head>
<body>
	<nav class="navbar navbar-expand-sm bg-dark justify-content-center mb-5">

			<span class="navbar-text h1 m-center" >
				FIELD
			</span>

	</nav>

	<div class="container m-center form-control col-sm-4" style="border-style:solid; border-color:">
		<form class=""action="processa.php" method="POST">
			<div class="form-group">
				<label for="login">Login:</label>
				<input class="form-control" placeholder="Login" type="text" name="login">
			</div>
			<br>
			<div class="form-group">
				<label for="senha">Senha:</label><br>
				<input class="form-control"type="password"  placeholder="Senha" name="senha">
			</div>
			<br>
			<input class="btn btn-dark m-auto"  type="submit" value="Acessar">
		</form>
	</div>

</body>
</html>
